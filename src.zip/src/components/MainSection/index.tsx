import { BiPlusCircle } from "react-icons/bi";
import { Container, FirstSection, MainCard, BitCard } from "./styles";
import { useEffect, useState } from "react";
import GameData from "../../interfaces";
import { getGames } from "../../services/api";

export default function MainSection() {

    const [games, setGames] = useState<GameData[]>([]);
    const [currentGame, setCurrentGame] = useState<GameData>();
    const [gameId, setGameId] = useState<number>(2);


    useEffect(() => {
        void (async () => {
            try {
                const gameRequest = await getGames();
                const { data: gameResponse } = gameRequest;
                setGames(gameResponse)
                setCurrentGame(gameResponse[0])
            } catch (error) {
                console.log(error);
            }
        })()
    }, []);


    useEffect(() => {
        const interval = setInterval(() => {
            games.forEach(game => {
                if (gameId === game.id) {
                    setCurrentGame(game);
                }
            })
            if (gameId === 6) {
                setGameId(1)
            } else {
                setGameId(gameId => gameId + 1)
            }
        }, 9000);

        return () => clearInterval(interval)
    }, [gameId, games])


    return (
        <Container>
            <FirstSection>
                <MainCard>
                <div className="shadow"></div>
                    {
                        games.map((game) => (
                            <img src={game.img} className={`game-${game?.id}` + ` ${currentGame?.id === game.id ? "active":""}`}/>
                        ))
                    }
                    <div className="info">
                        <img />
                        <div style={{ width: '63%', height: '150px', display: 'flex', alignItems: 'flex-start', justifyContent: 'flex-end', marginBottom: '34px', flexDirection: 'column'}}>
                            <span id="subtitle">{currentGame?.subtitle}</span>
                            <span id="description">{currentGame?.description}</span>
                        </div>
                        <span id="price">{currentGame?.price === 0 ? "Gratuito" : `A partir de R$ ${String(currentGame?.price.toFixed(2)).replace(".", ",")}`}</span>
                        <div id="btns">
                            <span id="purchase">{
                                                [currentGame?.released && currentGame?.price ===0 && "JOGUE DE GRAÇA",
                                                currentGame?.released && currentGame?.price !==0 && "COMPRE AGORA",
                                                currentGame?.released === false && "COMPRE JÁ NA PRÉ-VENDA",
                                            ]
                                                }</span>
                            <span id="wish-list"><span id="icon"><BiPlusCircle /></span>PARA A LISTA DE DESEJOS</span>
                        </div>
                    </div>
                </MainCard>
                <ul>
                    {
                        games.map((game) => (
                            <BitCard key={game.id} onClick={() => {
                                setGameId(game.id + 1)
                                setCurrentGame(game)
                            }}>
                                <div className={`mini-card ` + `${currentGame?.id === game.id ? "active" : ""}`} />
                                <img src={game.bitImg} className={`img-card ` + `${currentGame?.id === game.id ? "active" : ""}`}/>
                                <span>{game.name}</span>
                            </BitCard>
                        ))
                    }
                </ul>
            </FirstSection>
        </Container>
    )
}