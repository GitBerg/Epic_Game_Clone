import { styled, keyframes } from "styled-components";


const fillRight = keyframes`
from{
    width: 1px;
}
to{
    transform: scaleX(100%);
}
`

const growUp = keyframes`
50%{
    transform: scale(1.1);
}
100%{
    transform: scale(1);
}
`
const getOff = keyframes`
    from{
        transform: translateX(0);
    }
    to{
        transform: translateX(-105px); 
    }
`

const getIn = keyframes`
    from{
        transform: translateX(85px);
    }
    to{
        transform: translateX(0px);
    }
`

const fadeIn = keyframes`
    from{
        opacity: 0;
    }
    to{
        opacity: 1;
    }
    
`

const fadeOut = keyframes`
    from{
        opacity: 1;
    }
    to{
        opacity: 0;
    }
`

export const Container = styled.main`
    width: 100%;
    height: 100%;
    background-color: #121212;
    display: flex;
    justify-content: center;
`

export const FirstSection = styled.section`
    width: 75%;
    height: 650px;
    display: flex;
    justify-content: flex-start;

    ul{
        width: 20%;
        li{
            background-color: #252525;
        }
    }

`

export const MainCard = styled.div`
    width: 80%;
    min-height: 300px;
    min-width: 550px;
    height: calc(100vw - 66.3vw);
    background-color: #121212;
    border-radius: 14px;
    display: flex;
    position: relative;
    overflow: hidden;
    font-family: 'Franklin Gothic Medium';
    cursor: pointer;

    img{
        object-fit: cover;
        width: 100%;
        overflow: hidden;
        position: absolute;
    }

   
    .game-1, .game-2, .game-3, .game-4, .game-5, .game-6{
        opacity: 1;
        animation: ${getOff} 300ms ease-out 150ms forwards, ${fadeOut} 100ms ease 200ms forwards;
        z-index: 10;
        &.active{
            opacity: 0;
            animation: ${getIn} 200ms ease-out 200ms, ${fadeIn} 100ms ease 210ms forwards;
            z-index: 5;
        }
    }

    .shadow{
        position: absolute;
        width: 100%;
        left: 0;
        top: 0;
        height: 100%;
        background: linear-gradient(to right, rgba(0 0 0 / 40%), rgba(0 0 0 / 0%));
        z-index: 100;
    }

    .info{
        overflow: visible;
        position: absolute;
        object-fit: cover;
        bottom: 55px;
        left: 55px;
        width: 500px;
        z-index: 100;

        #subtitle{
            color: #EAF5F5;
            font-size: 0.9rem;
            line-height: 2.2rem;
        }

        #description{   
            display: -webkit-box;
            color: #EAF5F5;
            font-weight: 500;
            font-size: 1.2rem;
            line-height: 1.8rem;
            -webkit-line-clamp: 4;
            overflow: hidden;
            text-overflow: ellipsis;
            direction: ltr;
            -webkit-box-orient: vertical; 
        }
        #price{
            display: block;
            color: #EAF5F5;
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 8px;
        }
        #btns{
            display: flex;
            align-items: center;
            gap: 8px;
            #purchase{
            color: #292929;
            background-color: #FFFFFF;
            border-radius: 4px;
            padding: 17px 21px;
            letter-spacing: 1px;
            font-size: 1rem;
        }
            #wish-list{
                color: #EAF5F5;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 0.77rem;
                letter-spacing: 1px;
                padding: 12px 21px;
                border-radius: 4px;
                transition: all 0.2s ease;
                #icon{
                    font-size: 1.5rem;
                    margin-right: 5px;
                    transform: translateY(2px);
                }
            }
            #wish-list:hover{
                background-color: rgb(255 255 255 / 15%);
            }
        } 
    }
`

export const BitCard = styled.span`
    display: flex;
    justify-content: flex-start;
    align-items: center;
    font-family: 'Franklin Gothic Medium';
    cursor: pointer;
    width: 230px;
    padding-left: 15px;
    padding-right: 12px;
    height: 105px;
    margin-left: 32px;
    border-radius: 20px;
    transition: all 0.2s ease;
    position: relative;
    margin-bottom: 3px;
    

    img{
        object-fit: fill;
        width: 60px;
        height: 80px;
        border-radius: 6px;
        z-index: 2;
        pointer-events: none;
    }
    span{
        padding-left: 15px;
        color: #EAF5F5;
        font-size: 1.09rem;
        font-weight: 100;
        line-height: 25px;
        z-index: 2;
        pointer-events: none;
    }

    .mini-card{
        position: absolute;
        width: 100%;
        height: 100%;
        border-radius: 16px;
        transform: translateX(-15px);
        transition: all 0.3s ease;
        z-index: 1;
        &:hover{
            background-color: rgb(255 255 255 / 12%);
        }
    }

    .mini-card.active{
        z-index: 1;
        background-color: #252525;
        overflow: hidden;
        &::before{
            content: '';
            position: absolute;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: rgb(255 255 255 / 10%);
            animation: ${fillRight} 9s linear;
        }
    }

    .img-card.active{
        animation: ${growUp} 0.4s ease-in-out;
    }
`;
