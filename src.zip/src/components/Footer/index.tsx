export default function Footer(){
    return(
        <h1>Eu sou o Footer</h1>
    )
}