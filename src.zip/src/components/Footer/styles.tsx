import { styled } from "styled-components";

const MySpan = styled.span``

export const Footer = (props:any) => (
    <MySpan {...props}>
        {/* eslint-disable-next-line @typescript-eslint/no-unsafe-member-access */}
        {props.children}
    </MySpan>
);